#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;
in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 lightColor;
in vec4 vertexColor;
in vec4 rawColor; // [Added] Input from vertex shader
in vec2 texCoord0;
in vec2 texCoord1;
out vec4 fragColor;

void main() {
    vec4 color = texture(Sampler0, texCoord0) * ColorModulator;
    
    // Check alpha channel for special rendering flags
    ivec4 ich = ivec4(round(texelFetch(
        Sampler0,
        ivec2(texCoord0 * textureSize(Sampler0, 0)),
        0
    ) * 255));

    switch (ich.a) {
       case 254:
            color *= rawColor; 
            break;
            
        case 200:
        case 253:
        case 252:
        case 100:
        case 50:
            color *= lightColor;
            color.rgb *= 0.9;
            break;

        default:
            color *= vertexColor;
            break;
    }

    if (color.a < 0.1) discard;

    fragColor = apply_fog(
        color,
        sphericalVertexDistance,
        cylindricalVertexDistance,
        FogEnvironmentalStart,
        FogEnvironmentalEnd,
        FogRenderDistanceStart,
        FogRenderDistanceEnd,
        FogColor
    );
}